package rushhourtest;

public class IllegalMoveException extends Exception {

	private static final long serialVersionUID = -1552327500999125270L;

	public IllegalMoveException(String message) {
		super(message);
	}
}
