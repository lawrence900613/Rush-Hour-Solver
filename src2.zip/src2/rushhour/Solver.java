package rushhour;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.*;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.PriorityQueue;

import rushhour.Board;



public class Solver {

	public final static int SIZE = 6;
	//private static char[][] toCopy = new char[6][6];
	private static Board solution;


	public static void solveFromFile(String inputPath, String outputPath) throws Exception{
		try {

			char[][] boardTC = new char[6][6];

			File file = new File(inputPath);
			Scanner reader = new Scanner(file);

			int row = 0;

			while (reader.hasNextLine()) {
				String temp = reader.nextLine();
				char[] array = temp.toCharArray();
				if (temp.length() != 6)
					throw new Exception("Bad file");
				boardTC[row] = array;
				row++;
			}

			// Close the file
			reader.close();

			//start solving
			Board temp = new Board(boardTC);

			BFS(temp);

			File file2 = new File(outputPath);
			PrintWriter pw = new PrintWriter(file2);

			Board temp2 = solution;

			for (String n : solution.move) {
				pw.println(n);
			}
			pw.close();
		}catch(Exception e){
			return;
		}
	}
	public static char[][] copy (char[][] in ) {
		char[][] temp = new char[6][6];
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				temp[i][j] = in[i][j];
			}
		}
		return temp;
	}
	public static void BFS (Board in ){
		//LinkedList<Vertex<Board>> queue = new LinkedList<Vertex<Board>>();

		LinkedList<Board> q = new LinkedList<Board>();

		q.add(in);

		int size = 0;
		HashMap<Integer,Board> duplicate = new HashMap<Integer, Board>();

		while (!q.isEmpty()) {
			Board current = q.remove();
			size ++;
			if (current.isSolved()) {
				solution = current;
				return;
			}
			for (char name : current.Vehicles) {
				int direction = current.direction(name);
				if (direction == 0) {
					for (int i = 1; i < 6; i++)
						try {
							char[][] temp2 = copy(current.board);
							Board temp = new Board(temp2);
							temp.makeMove(name, 0, i);
							temp.move.addAll(current.move);
							temp.move.add( name+"U" + i );
							if(!duplicate.containsKey(temp.hashCode())) {
								q.add(temp);
								duplicate.put(temp.hashCode(),temp);
							}
						} catch (Exception e) {
							break;
						}
					for (int i = 1; i < 6; i++)
						try {
							char[][] temp2 = copy(current.board);
							Board temp = new Board(temp2);
							temp.makeMove(name, 1, i);
							temp.move.addAll(current.move);
							temp.move.add( name+"D" + i  );
							if(!duplicate.containsKey(temp.hashCode())) {
								q.add(temp);
								duplicate.put(temp.hashCode(),temp);
							}else{
								continue;
							}
						} catch (Exception e) {
							break;
						}

				} else {
					for (int i = 1; i < 6; i++)
						try {
							char[][] temp2 = copy(current.board);
							Board temp = new Board(temp2);
							temp.makeMove(name, 2, i);
							temp.move.addAll(current.move);
							temp.move.add( name+"L" + i  );
							if(!duplicate.containsKey(temp.hashCode())) {
								q.add(temp);
								duplicate.put(temp.hashCode(),temp);
							}
						} catch (Exception e) {
							break;
						}
					for (int i = 1; i < 6; i++)
						try {
							char[][] temp2 = copy(current.board);
							Board temp = new Board(temp2);
							temp.makeMove(name, 3, i);
							temp.move.addAll(current.move);
							temp.move.add(  name+"R" + i  );
							if(!duplicate.containsKey(temp.hashCode())) {
								q.add(temp);
								duplicate.put(temp.hashCode(),temp);
							}
						} catch (Exception e) {
							break;
						}

				}

			}
			if(!duplicate.containsKey(current.hashCode())) {
				q.add(current);
				duplicate.put(current.hashCode(),current);
			}

		}
	}




	public static void main(String[] args) throws Exception {
		solveFromFile("A00.txt","output1.txt");
	}
}
