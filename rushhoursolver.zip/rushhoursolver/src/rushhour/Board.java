package rushhour;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class Board {
    public char[][] board = new char[6][6];

    public ArrayList<Character> Vehicles = new ArrayList<Character>();

    public int totalVehicle;

    public ArrayList<String> move = new ArrayList<String>();

    /*
    public final static int UP = 0;
    public final static int DOWN = 1;
    public final static int LEFT = 2;
    public final static int RIGHT = 3;
*/


    public void move (ArrayList<String> move2 ){
        move.addAll(move2);
    }
    public Board(char[][] in){
        board = in;
        allVehicle();
    }

    public char getter(int a, int b){
        return board[a][b];
    }

    public void setter(int a, int b, char C){
        board[a][b] = C;
    }

    public int direction(char carName ){
        int F1 = -10, F2 = -10;
        int L1 = -10, L2 = -10;
        int count = 0;
        for (int i = 0; i <= 5; i++) {
            int temp1 = -1, temp2 = -1;
            for (int j = 0; j <= 5; j++) {
                if (carName == board[i][j]) {
                    temp1 = i;
                    temp2 = j;
                }

                if (temp1 > -1 && temp2 > -1 && count == 0) {
                    F1 = temp1;
                    F2 = temp2;
                    count++;
                } else if (temp1 > -1 && temp2 > -1 && count == 1) {
                    L1 = temp1;
                    L2 = temp2;
                }
            }
        }
        int direction; // 1 is vertical for car
        // 0 is horizontal for car
        if (F1 == L1)
            direction = 1;
        else
            direction = 0;
        return direction;

    }


    public boolean clean0(int R, int j, char[][] temp, int le,char carName) {
        if (R - le < 0)
            return false;
        for (int i = R; i >= R - le; i--) {
            if (temp[i][j] == '.' || temp[i][j] == carName)
                continue;
            else
                return false;
        }
        return true;
    }

    public boolean clean1(int R, int j, char[][] temp, int le,char carName) {
        if (R + le > 5)
            return false;
        for (int i = R; i <= R + le; i++) {
            if (temp[i][j] == '.' || temp[i][j] == carName)
                continue;
            else
                return false;
        }
        return true;
    }

    public boolean clean2(int R, int j, char[][] temp, int le,char carName) {
        if (j - le < 0)
            return false;
        for (int i = j; i >= j - le; i--) {
            if (temp[R][i] == '.' || temp[R][i] == carName)
                continue;
            else
                return false;
        }
        return true;
    }

    public boolean clean3(int R, int j, char[][] temp, int le,char carName) {
        if (j + le > 5)
            return false;
        for (int i = j; i <= j + le; i++) {
            if (temp[R][i] == '.' || temp[R][i] == carName)
                continue;
            else
                return false;
        }
        return true;
    }

    public void makeMove(char carName, int dir, int length) throws Exception {
        // TODO implement me
        int F1 = -10, F2 = -10;
        int L1 = -10, L2 = -10;
        int count = 0;
        for (int i = 0; i <= 5; i++) {
            int temp1 = -1, temp2 = -1;
            for (int j = 0; j <= 5; j++) {
                if (carName == board[i][j]) {
                    temp1 = i;
                    temp2 = j;
                }

                if (temp1 > -1 && temp2 > -1 && count == 0) {
                    F1 = temp1;
                    F2 = temp2;
                    count++;
                } else if (temp1 > -1 && temp2 > -1 && count == 1) {
                    L1 = temp1;
                    L2 = temp2;
                }
            }
        }
        int direction; // 1 is vertical
        // 0 is horizontal
        if (F1 == L1)
            direction = 1;
        else
            direction = 0;

        switch (dir) {
            case 0: {
                if (direction == 1)
                    throw new Exception("Illegal direction");
                else {
                    int count0 = 0;
                    for (int i = 0; i <= 5; i++) {
                        for (int j = 0; j <= 5; j++) {
                            if (carName == board[i][j]) {
                                if (count0 == 0 && (i - length) >= 0 && clean0(i, j, board, length,carName)) {
                                    board[i - length][j] = carName;
                                    board[i][j] = '.';
                                    count0++;
                                } else if(count0 == 0) {
                                    throw new Exception("Illegalmove 0");
                                }else if (count0 != 0) {
                                    board[i - length][j] = carName;
                                    board[i][j] = '.';
                                }
                            }
                        }
                    }
                }
                break;
            }
            case 1: {
                if (direction == 1)
                    throw new Exception("Illegal direction");
                else {
                    int count0 = 0;
                    for (int i = 5; i >= 0; i--) {
                        for (int j = 5; j >= 0; j--) {
                            if (carName == board[i][j]) {
                                if (count0 == 0 && (i + length) <= 5 && clean1(i, j, board, length,carName)) {
                                    board[i + length][j] = carName;
                                    board[i][j] = '.';
                                    count0++;
                                } else if(count0 == 0){
                                    throw new Exception("Illegalmove 1");}
                                else if (count0 != 0) {
                                    board[i + length][j] = carName;
                                    board[i][j] = '.';
                                }
                            }
                        }
                    }
                }
                break;
            }
            case 2: {
                if (direction == 0)
                    throw new Exception("Illegal direction");
                else {
                    int count0 = 0;
                    for (int i = 0; i < 6; i++) {
                        for (int j = 0; j < 6; j++) {
                            if (carName == board[i][j]) {
                                if (count0 == 0 && (j - length) >= 0 && clean2(i, j, board, length,carName)) {
                                    board[i][j - length] = carName;
                                    board[i][j] = '.';
                                    count0++;
                                } else if(count0 == 0) {
                                    throw new Exception("Illegalmove 2");
                                } else if (count0 != 0) {
                                    board[i][j - length] = carName;
                                    board[i][j] = '.';
                                }
                            }
                        }
                    }

                }
                break;
            }
            case 3: {
                if (direction == 0)
                    throw new Exception("Illegal direction");
                else {
                    int count0 = 0;
                    for (int i = 5; i >= 0; i--) {
                        for (int j = 5; j >= 0; j--) {
                            if (carName == board[i][j]) {
                                if (count0 == 0 && (j + length) <= 5 && clean3(i, j, board, length,carName)) {
                                    board[i][j + length] = carName;
                                    board[i][j] = '.';
                                    count0++;
                                } else if(count0 == 0) {
                                    throw new Exception("Illegalmove 3");
                                }else if (count0 != 0) {
                                    board[i][j + length] = carName;
                                    board[i][j] = '.';
                                }
                            }
                        }
                    }
                }
                break;
            }


        }
        // 6x6 array 遇到障礙物 throw
    }


    public void allVehicle(){
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++){
                if (board[i][j] != '.' && !Vehicles.contains(board[i][j])){
                    Vehicles.add(board[i][j]);
                    totalVehicle++;
                }
            }
        }
    }

    public boolean isSolved() {
        if(board[2][5] == 'X'){
            return true;
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Board board1 = (Board) o;
        return  Arrays.equals(board, board1.board) ;
    }

    @Override
    public int hashCode() {
        int result = 31 * Arrays.deepHashCode(board);
        return result;
    }
}